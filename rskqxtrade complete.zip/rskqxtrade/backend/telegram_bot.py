"""
RSKQxTrade — Telegram Bot
Commandes + boutons inline + ouverture Mini App
"""
import asyncio
import logging
from datetime import datetime, timezone

from telegram import (
    Update, InlineKeyboardButton, InlineKeyboardMarkup,
    WebAppInfo, MenuButtonWebApp, ReplyKeyboardMarkup, KeyboardButton,
)
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler,
    ContextTypes, MessageHandler, filters,
)
from telegram.constants import ParseMode

from config import TELEGRAM_BOT_TOKEN, ASSET_SYMBOLS, EXPIRATIONS, WEBAPP_URL, APP_URL

logger = logging.getLogger("telegram_bot")

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# FORMATTERS
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def _dir_emoji(direction: str) -> str:
    return {"CALL": "🔵", "PUT": "🔴", "NO TRADE": "⚪"}.get(direction, "❓")

def _conf_emoji(confidence: str) -> str:
    return {"HIGH": "🔥", "MEDIUM": "✅", "LOW": "⚠️", "INSUFFICIENT": "❌"}.get(confidence, "❓")


def format_signal_msg(sig: dict, show_tf: bool = True) -> str:
    d   = sig.get("direction", "?")
    de  = _dir_emoji(d)
    ce  = _conf_emoji(sig.get("confidence", "?"))

    lines = [
        f"{de} *{sig.get('asset', '?')}* — `{sig.get('expiry', '?')}`",
        f"",
        f"Direction   : *{d}*",
        f"Probabilité : *{sig.get('probability', 0):.1f}%*",
        f"Confiance   : {ce} *{sig.get('confidence', '?')}*",
        f"Prix actuel : `{sig.get('current_price', 0)}`",
        f"Expiration  : `{sig.get('target_time', '?')}`",
        f"",
        f"💬 _{sig.get('reason', '')}_",
    ]

    if show_tf and sig.get("tf_breakdown"):
        lines.append("")
        lines.append("*Timeframes :*")
        for tf, info in sig.get("tf_breakdown", {}).items():
            lines.append(f"  `{tf}` {info}")

    lines.append("")
    lines.append("⚠️ _Signal algorithmique — pas un conseil financier_")
    return "\n".join(lines)


def format_scan_msg(signals: dict) -> str:
    lines = ["🔍 *Scan de marché*\n"]
    for sym, sig in signals.items():
        de = _dir_emoji(sig.get("direction", "?"))
        prob = sig.get("probability", 0)
        conf = sig.get("confidence", "?")
        lines.append(f"{de} *{sym}* | {prob:.0f}% | {conf}")
    lines.append("")
    lines.append("_Utilise /signal [actif] [expiry] pour les détails_")
    return "\n".join(lines)


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# KEYBOARDS
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def main_keyboard() -> ReplyKeyboardMarkup:
    """Clavier persistant avec bouton d'ouverture de la Mini App."""
    return ReplyKeyboardMarkup(
        keyboard=[[
            KeyboardButton(
                text="📊 Ouvrir l'app de trading",
                web_app=WebAppInfo(url=WEBAPP_URL),
            )
        ], [
            KeyboardButton("🔍 Scan rapide"),
            KeyboardButton("📈 EUR/USD"),
            KeyboardButton("🪙 BTC/USD"),
        ]],
        resize_keyboard=True,
        one_time_keyboard=False,
    )


def asset_keyboard(expiry: str = "1m") -> InlineKeyboardMarkup:
    """Sélection d'actif en inline."""
    rows = []
    row = []
    for i, sym in enumerate(ASSET_SYMBOLS):
        short = sym.replace("/USD", "").replace("USD/", "U/")
        row.append(InlineKeyboardButton(short, callback_data=f"sig:{sym}:{expiry}"))
        if len(row) == 3:
            rows.append(row)
            row = []
    if row:
        rows.append(row)

    # Expiry row
    rows.append([
        InlineKeyboardButton(f"{'✓ ' if e == expiry else ''}{e}", callback_data=f"exp:{e}")
        for e in EXPIRATIONS[:4]
    ])
    rows.append([
        InlineKeyboardButton(f"{'✓ ' if e == expiry else ''}{e}", callback_data=f"exp:{e}")
        for e in EXPIRATIONS[4:]
    ])
    return InlineKeyboardMarkup(rows)


def signal_action_keyboard(asset: str, expiry: str) -> InlineKeyboardMarkup:
    """Keyboard sous un signal : rafraîchir, changer actif."""
    return InlineKeyboardMarkup([[
        InlineKeyboardButton("🔄 Rafraîchir", callback_data=f"sig:{asset}:{expiry}"),
        InlineKeyboardButton("📋 Tous", callback_data=f"scan:{expiry}"),
        InlineKeyboardButton(
            "📱 Mini App",
            web_app=WebAppInfo(url=WEBAPP_URL),
        ),
    ]])


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# ÉTAT LOCAL (expiry par user)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

user_expiry: dict = {}   # user_id → expiry choisi

def get_expiry(user_id: int) -> str:
    return user_expiry.get(user_id, "1m")


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# COMMANDES
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

async def cmd_start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    name = update.effective_user.first_name or "trader"
    msg = (
        f"👋 Salut *{name}* !\n\n"
        f"🤖 *RSKQxTrade* — Analyse multi-timeframe temps réel\n\n"
        f"📡 *5 actifs :* EUR/USD · BTC/USD · GBP/USD · XAU/USD · USD/JPY\n"
        f"⏱ *Expirations :* {' · '.join(EXPIRATIONS)}\n\n"
        f"*Commandes :*\n"
        f"/signal EUR/USD 1m — Signal détaillé\n"
        f"/scan — Scan de tous les actifs\n"
        f"/expiry 5m — Changer l'expiration\n"
        f"/app — Ouvrir la Mini App\n\n"
        f"Ou appuie sur le bouton ci-dessous pour l'app complète 👇"
    )
    await update.message.reply_text(
        msg,
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=main_keyboard(),
    )


async def cmd_signal(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """
    /signal [ACTIF] [EXPIRY]
    ex: /signal EUR/USD 5m
    """
    uid    = update.effective_user.id
    args   = ctx.args
    expiry = get_expiry(uid)
    asset  = "EUR/USD"

    if len(args) >= 1:
        candidate = args[0].upper().replace("-", "/")
        if candidate in ASSET_SYMBOLS:
            asset = candidate
        else:
            await update.message.reply_text(
                f"❌ Actif inconnu. Disponibles :\n{', '.join(ASSET_SYMBOLS)}"
            )
            return

    if len(args) >= 2 and args[1] in EXPIRATIONS:
        expiry = args[1]
        user_expiry[uid] = expiry

    loading_msg = await update.message.reply_text(
        f"⏳ Analyse de *{asset}* {expiry}...",
        parse_mode=ParseMode.MARKDOWN,
    )

    try:
        import aiohttp
        async with aiohttp.ClientSession() as session:
            url = f"http://localhost:8000/signal/{asset.replace('/', '-')}"
            async with session.get(url, params={"expiry": expiry}, timeout=aiohttp.ClientTimeout(total=30)) as resp:
                sig = await resp.json()

        text = format_signal_msg(sig)
        await loading_msg.delete()
        await update.message.reply_text(
            text,
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=signal_action_keyboard(asset, expiry),
        )
    except Exception as e:
        logger.error(f"cmd_signal: {e}")
        await loading_msg.edit_text(f"❌ Erreur: {str(e)[:100]}")


async def cmd_scan(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """Scanne tous les actifs."""
    uid    = update.effective_user.id
    expiry = get_expiry(uid)

    loading = await update.message.reply_text("⏳ Scan en cours...")

    try:
        import aiohttp
        async with aiohttp.ClientSession() as session:
            async with session.get(
                f"http://localhost:8000/scan",
                params={"expiry": expiry},
                timeout=aiohttp.ClientTimeout(total=60),
            ) as resp:
                signals = await resp.json()

        text = format_scan_msg(signals)
        kb   = InlineKeyboardMarkup([[
            InlineKeyboardButton(
                f"📊 {sym.replace('/USD', '').replace('USD/', 'U/')}",
                callback_data=f"sig:{sym}:{expiry}"
            ) for sym in list(signals.keys())[:3]
        ], [
            InlineKeyboardButton(
                f"📊 {sym.replace('/USD', '').replace('USD/', 'U/')}",
                callback_data=f"sig:{sym}:{expiry}"
            ) for sym in list(signals.keys())[3:]
        ], [
            InlineKeyboardButton("📱 Mini App", web_app=WebAppInfo(url=WEBAPP_URL)),
        ]])

        await loading.delete()
        await update.message.reply_text(
            text,
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=kb,
        )
    except Exception as e:
        logger.error(f"cmd_scan: {e}")
        await loading.edit_text(f"❌ Erreur lors du scan: {str(e)[:100]}")


async def cmd_expiry(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """Définit l'expiration par défaut."""
    uid  = update.effective_user.id
    args = ctx.args
    if not args or args[0] not in EXPIRATIONS:
        kb = InlineKeyboardMarkup([[
            InlineKeyboardButton(e, callback_data=f"exp:{e}") for e in EXPIRATIONS
        ]])
        await update.message.reply_text(
            f"⏱ Choisis une expiration :",
            reply_markup=kb,
        )
        return
    exp = args[0]
    user_expiry[uid] = exp
    await update.message.reply_text(f"✅ Expiration par défaut : *{exp}*", parse_mode=ParseMode.MARKDOWN)


async def cmd_app(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """Ouvre la Mini App."""
    kb = InlineKeyboardMarkup([[
        InlineKeyboardButton(
            "📊 Ouvrir RSKQxTrade",
            web_app=WebAppInfo(url=WEBAPP_URL),
        )
    ]])
    await update.message.reply_text(
        "📱 Lance la Mini App pour une expérience complète :",
        reply_markup=kb,
    )


async def cmd_prices(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """Prix actuels de tous les actifs."""
    try:
        import aiohttp
        async with aiohttp.ClientSession() as session:
            async with session.get("http://localhost:8000/prices",
                                   timeout=aiohttp.ClientTimeout(total=10)) as resp:
                prices = await resp.json()

        lines = ["💰 *Prix actuels*\n"]
        for sym, info in prices.items():
            p = info.get("price")
            c = "🟢" if info.get("connected") else "🔴"
            lines.append(f"{c} `{sym}` : `{p or 'N/A'}`")
        lines.append(f"\n_Mis à jour : {datetime.now(timezone.utc).strftime('%H:%M:%S UTC')}_")

        await update.message.reply_text("\n".join(lines), parse_mode=ParseMode.MARKDOWN)
    except Exception as e:
        await update.message.reply_text(f"❌ Erreur: {e}")


async def cmd_help(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    msg = (
        "🤖 *RSKQxTrade — Commandes*\n\n"
        "/start — Menu principal\n"
        "/signal `[ACTIF]` `[EXPIRY]` — Signal détaillé\n"
        "  _ex : /signal EUR/USD 5m_\n"
        "/scan — Scan de tous les actifs\n"
        "/expiry `[DURÉE]` — Changer l'expiration\n"
        "  _ex : /expiry 5m_\n"
        "/prices — Prix actuels\n"
        "/app — Ouvrir la Mini App\n\n"
        f"*Actifs :* {' · '.join(ASSET_SYMBOLS)}\n"
        f"*Expirations :* {' · '.join(EXPIRATIONS)}"
    )
    await update.message.reply_text(msg, parse_mode=ParseMode.MARKDOWN, reply_markup=main_keyboard())


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# CALLBACKS INLINE
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

async def callback_handler(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query  = update.callback_query
    uid    = query.from_user.id
    data   = query.data
    await query.answer()

    if data.startswith("sig:"):
        _, asset, expiry = data.split(":")
        await query.edit_message_text("⏳ Analyse en cours...", parse_mode=ParseMode.MARKDOWN)
        try:
            import aiohttp
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    f"http://localhost:8000/signal/{asset.replace('/', '-')}",
                    params={"expiry": expiry},
                    timeout=aiohttp.ClientTimeout(total=30),
                ) as resp:
                    sig = await resp.json()

            await query.edit_message_text(
                format_signal_msg(sig),
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=signal_action_keyboard(asset, expiry),
            )
        except Exception as e:
            await query.edit_message_text(f"❌ Erreur: {str(e)[:80]}")

    elif data.startswith("exp:"):
        expiry = data.split(":")[1]
        user_expiry[uid] = expiry
        await query.edit_message_text(
            f"✅ Expiration : *{expiry}*\n\n_Choisis un actif :_",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=asset_keyboard(expiry),
        )

    elif data.startswith("scan:"):
        expiry = data.split(":")[1]
        await query.edit_message_text("⏳ Scan en cours...")
        try:
            import aiohttp
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    "http://localhost:8000/scan",
                    params={"expiry": expiry},
                    timeout=aiohttp.ClientTimeout(total=60),
                ) as resp:
                    signals = await resp.json()
            await query.edit_message_text(
                format_scan_msg(signals),
                parse_mode=ParseMode.MARKDOWN,
            )
        except Exception as e:
            await query.edit_message_text(f"❌ Erreur scan: {e}")


# ── Handler texte libre (boutons clavier persistant)
async def text_handler(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    text = update.message.text
    uid  = update.effective_user.id
    expiry = get_expiry(uid)

    if "Scan" in text:
        ctx.args = []
        await cmd_scan(update, ctx)
    elif "EUR/USD" in text:
        ctx.args = ["EUR/USD", expiry]
        await cmd_signal(update, ctx)
    elif "BTC/USD" in text:
        ctx.args = ["BTC/USD", expiry]
        await cmd_signal(update, ctx)


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# BUILD & RUN
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def build_bot() -> Application:
    app = Application.builder().token(TELEGRAM_BOT_TOKEN).build()

    app.add_handler(CommandHandler("start",   cmd_start))
    app.add_handler(CommandHandler("signal",  cmd_signal))
    app.add_handler(CommandHandler("scan",    cmd_scan))
    app.add_handler(CommandHandler("expiry",  cmd_expiry))
    app.add_handler(CommandHandler("app",     cmd_app))
    app.add_handler(CommandHandler("prices",  cmd_prices))
    app.add_handler(CommandHandler("help",    cmd_help))
    app.add_handler(CallbackQueryHandler(callback_handler))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, text_handler))

    return app


async def run_bot_polling():
    """Lance le bot en polling (Replit/local)."""
    bot = build_bot()
    await bot.initialize()
    await bot.start()
    logger.info("✅ Bot Telegram démarré (polling)")
    await bot.updater.start_polling(drop_pending_updates=True)
    await asyncio.Event().wait()


async def setup_webhook(webhook_url: str):
    """Configure le webhook (production Vercel)."""
    bot = build_bot()
    await bot.initialize()
    await bot.bot.set_webhook(
        url=webhook_url,
        allowed_updates=["message", "callback_query"],
    )
    logger.info(f"✅ Webhook configuré: {webhook_url}")
    return bot
