"""
RSKQxTrade — Market Data Manager
WebSocket temps réel + REST TwelveData
Reconnexion automatique, buffer de ticks, construction de bougies
"""
import asyncio
import json
import logging
import time
from collections import defaultdict, deque
from datetime import datetime, timezone, timedelta
from typing import Callable, Dict, List, Optional, Set

import aiohttp
import websockets
from websockets.exceptions import ConnectionClosedError, ConnectionClosedOK

from config import (
    TWELVEDATA_API_KEY, TD_REST_BASE, TD_WS_URL,
    ASSETS, TIMEFRAMES, ASSET_SYMBOLS,
)
from models.schemas import Candle, Tick, MarketState

logger = logging.getLogger("market_data")


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# TICK BUFFER — construit des bougies depuis les ticks bruts
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

class CandleBuilder:
    """
    Construit des bougies OHLCV depuis un flux de ticks.
    Supporte plusieurs timeframes simultanément.
    """

    def __init__(self, symbol: str, max_candles: int = 200):
        self.symbol      = symbol
        self.max_candles = max_candles
        # candles[tf_seconds] = deque of Candle
        self.candles: Dict[int, deque] = {
            5:   deque(maxlen=max_candles),
            15:  deque(maxlen=max_candles),
            30:  deque(maxlen=max_candles),
            60:  deque(maxlen=max_candles),
            120: deque(maxlen=max_candles),
            300: deque(maxlen=max_candles),
        }
        # Bougie en cours de construction par TF
        self._current: Dict[int, Optional[dict]] = {tf: None for tf in self.candles}

    def _tf_bucket(self, ts: datetime, tf_seconds: int) -> datetime:
        """Retourne le timestamp de début de la bougie contenant ts."""
        epoch = int(ts.timestamp())
        bucket = (epoch // tf_seconds) * tf_seconds
        return datetime.fromtimestamp(bucket, tz=timezone.utc)

    def feed(self, tick: Tick) -> Dict[int, Optional[Candle]]:
        """
        Ingère un tick et retourne les bougies complétées par TF (si elles se ferment).
        Returns: {tf_seconds: Candle} pour les bougies qui viennent de fermer
        """
        completed: Dict[int, Optional[Candle]] = {}

        for tf_sec in self.candles:
            bucket = self._tf_bucket(tick.timestamp, tf_sec)
            current = self._current[tf_sec]

            if current is None:
                # Première bougie
                self._current[tf_sec] = {
                    "ts": bucket, "o": tick.price, "h": tick.price,
                    "l": tick.price, "c": tick.price, "v": 0.0,
                }
                completed[tf_sec] = None

            elif bucket > current["ts"]:
                # La bougie courante est terminée
                c = self._current[tf_sec]
                candle = Candle(
                    timestamp=c["ts"], open=c["o"], high=c["h"],
                    low=c["l"], close=c["c"], volume=c["v"],
                )
                self.candles[tf_sec].append(candle)
                completed[tf_sec] = candle

                # Commence la nouvelle
                self._current[tf_sec] = {
                    "ts": bucket, "o": tick.price, "h": tick.price,
                    "l": tick.price, "c": tick.price, "v": 0.0,
                }
            else:
                # Met à jour la bougie courante
                current["h"] = max(current["h"], tick.price)
                current["l"] = min(current["l"], tick.price)
                current["c"] = tick.price
                completed[tf_sec] = None

        return completed

    def get_candles(self, tf_seconds: int) -> List[Candle]:
        """Retourne la liste des bougies fermées pour un TF donné."""
        candles = list(self.candles[tf_seconds])
        # Ajoute la bougie en cours (non fermée) à la fin si elle existe
        current = self._current.get(tf_seconds)
        if current:
            candles.append(Candle(
                timestamp=current["ts"], open=current["o"], high=current["h"],
                low=current["l"], close=current["c"], volume=current["v"],
            ))
        return candles


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# TWELVEDATA REST — chargement historique initial
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

async def fetch_historical(session: aiohttp.ClientSession, symbol: str,
                            interval: str, outputsize: int = 120) -> List[Candle]:
    """Récupère l'historique OHLCV depuis TwelveData REST."""
    td_symbol = ASSETS[symbol]["td_symbol"]
    url = f"{TD_REST_BASE}/time_series"
    params = {
        "symbol":     td_symbol,
        "interval":   interval,
        "outputsize": outputsize,
        "apikey":     TWELVEDATA_API_KEY,
        "timezone":   "UTC",
        "order":      "ASC",
    }

    try:
        async with session.get(url, params=params, timeout=aiohttp.ClientTimeout(total=15)) as resp:
            data = await resp.json()

        if data.get("status") == "error":
            logger.error(f"TwelveData error {symbol} {interval}: {data.get('message')}")
            return []

        values = data.get("values", [])
        candles = []
        for v in values:
            try:
                candles.append(Candle(
                    timestamp=datetime.fromisoformat(v["datetime"].replace("Z", "+00:00")),
                    open=float(v["open"]),
                    high=float(v["high"]),
                    low=float(v["low"]),
                    close=float(v["close"]),
                    volume=float(v.get("volume", 0)),
                ))
            except Exception:
                continue

        logger.info(f"✅ Historique {symbol} {interval}: {len(candles)} bougies")
        return candles

    except Exception as e:
        logger.error(f"fetch_historical {symbol} {interval}: {e}")
        return []


async def fetch_current_price(session: aiohttp.ClientSession, symbol: str) -> Optional[float]:
    """Récupère le dernier prix via TwelveData."""
    td_symbol = ASSETS[symbol]["td_symbol"]
    url = f"{TD_REST_BASE}/price"
    try:
        async with session.get(url, params={"symbol": td_symbol, "apikey": TWELVEDATA_API_KEY},
                               timeout=aiohttp.ClientTimeout(total=8)) as resp:
            data = await resp.json()
        return float(data.get("price", 0)) or None
    except Exception:
        return None


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# MARKET DATA MANAGER — gestionnaire central
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

class MarketDataManager:
    """
    Gestionnaire de données de marché centralisé.
    - Connexion WebSocket TwelveData (ticks temps réel)
    - Construction de bougies multi-TF depuis les ticks
    - Chargement de l'historique au démarrage
    - Reconnexion automatique
    - Callbacks sur nouveau tick / nouvelle bougie
    """

    def __init__(self):
        self.builders:     Dict[str, CandleBuilder] = {s: CandleBuilder(s) for s in ASSET_SYMBOLS}
        self.states:       Dict[str, MarketState]   = {s: MarketState(symbol=s) for s in ASSET_SYMBOLS}
        self._tick_cbs:    List[Callable]            = []
        self._candle_cbs:  List[Callable]            = []
        self._ws           = None
        self._running      = False
        self._session:     Optional[aiohttp.ClientSession] = None
        self._reconnect_delay = 2   # secondes
        self._max_reconnect   = 30

        # Dernier prix connu par symbole (fallback quand WS déconnecté)
        self._last_price: Dict[str, float] = {}

    # ── Callbacks ────────────────────────────────────────────────────────────

    def on_tick(self, fn: Callable):
        """Enregistre un callback appelé sur chaque tick. fn(tick: Tick)"""
        self._tick_cbs.append(fn)

    def on_candle(self, fn: Callable):
        """Enregistre un callback appelé sur chaque nouvelle bougie fermée.
           fn(symbol: str, tf_seconds: int, candle: Candle)"""
        self._candle_cbs.append(fn)

    # ── Accesseurs ───────────────────────────────────────────────────────────

    def get_candles(self, symbol: str, tf_label: str) -> List[Candle]:
        """Retourne les bougies pour un actif et un TF donné."""
        tf_cfg = TIMEFRAMES.get(tf_label)
        if not tf_cfg:
            return []
        return self.builders[symbol].get_candles(tf_cfg["seconds"])

    def get_price(self, symbol: str) -> Optional[float]:
        state = self.states[symbol]
        if state.last_tick:
            return state.last_tick.price
        return self._last_price.get(symbol)

    def is_ready(self, symbol: str) -> bool:
        """Vérifie si on a assez de données pour analyser."""
        candles_1m = self.get_candles(symbol, "1m")
        return len(candles_1m) >= 30

    # ── Initialisation historique ─────────────────────────────────────────────

    async def bootstrap(self):
        """
        Charge l'historique initial pour tous les actifs et TF.
        Appelé une fois au démarrage avant la connexion WS.
        """
        self._session = aiohttp.ClientSession()
        logger.info("📡 Chargement historique initial...")

        tasks = []
        for symbol in ASSET_SYMBOLS:
            # On a besoin de 1min et 5min pour couvrir tous nos TF
            for interval in ["1min", "2min", "5min"]:
                tasks.append(self._load_and_seed(symbol, interval))

        await asyncio.gather(*tasks, return_exceptions=True)

        # Charge les prix actuels
        price_tasks = [self._load_current_price(s) for s in ASSET_SYMBOLS]
        await asyncio.gather(*price_tasks, return_exceptions=True)

        logger.info("✅ Bootstrap terminé")

    async def _load_and_seed(self, symbol: str, interval: str):
        """Charge l'historique et l'injecte dans le builder."""
        tf_seconds_map = {"1min": [5, 15, 30, 60], "2min": [120], "5min": [300]}
        candles = await fetch_historical(self._session, symbol, interval, outputsize=150)

        target_tfs = tf_seconds_map.get(interval, [60])
        for candle in candles:
            for tf_sec in target_tfs:
                bucket_ts = int(candle.timestamp.timestamp()) // tf_sec * tf_sec
                bucket_dt = datetime.fromtimestamp(bucket_ts, tz=timezone.utc)
                # Réinjecte dans le builder comme si c'était des bougies closes
                if self.builders[symbol].candles[tf_sec]:
                    last = self.builders[symbol].candles[tf_sec][-1]
                    if last.timestamp >= bucket_dt:
                        continue
                self.builders[symbol].candles[tf_sec].append(Candle(
                    timestamp=bucket_dt,
                    open=candle.open, high=candle.high,
                    low=candle.low, close=candle.close,
                    volume=candle.volume,
                ))

    async def _load_current_price(self, symbol: str):
        price = await fetch_current_price(self._session, symbol)
        if price:
            self._last_price[symbol] = price
            now = datetime.now(timezone.utc)
            tick = Tick(symbol=symbol, price=price, timestamp=now)
            self.states[symbol].last_tick = tick
            logger.info(f"💰 {symbol}: {price}")

    # ── WebSocket TwelveData ──────────────────────────────────────────────────

    async def start(self):
        """Démarre le gestionnaire (bootstrap + WebSocket)."""
        self._running = True
        await self.bootstrap()
        asyncio.create_task(self._ws_loop())
        asyncio.create_task(self._heartbeat())

    async def stop(self):
        self._running = False
        if self._ws:
            await self._ws.close()
        if self._session:
            await self._session.close()

    async def _ws_loop(self):
        """Boucle de connexion WebSocket avec reconnexion automatique."""
        delay = self._reconnect_delay

        while self._running:
            try:
                logger.info(f"🔌 Connexion WebSocket TwelveData...")
                async with websockets.connect(
                    TD_WS_URL,
                    ping_interval=20,
                    ping_timeout=10,
                    close_timeout=5,
                ) as ws:
                    self._ws = ws
                    delay = self._reconnect_delay  # reset delay

                    # Authentification
                    await ws.send(json.dumps({
                        "action": "signin",
                        "params": {"apikey": TWELVEDATA_API_KEY},
                    }))

                    # Souscription aux actifs
                    symbols_list = [ASSETS[s]["td_symbol"] for s in ASSET_SYMBOLS]
                    await ws.send(json.dumps({
                        "action": "subscribe",
                        "params": {"symbols": symbols_list},
                    }))

                    # Marque connecté
                    for s in ASSET_SYMBOLS:
                        self.states[s].is_connected = True
                    logger.info(f"✅ WS connecté — {len(symbols_list)} actifs souscrits")

                    async for msg in ws:
                        if not self._running:
                            break
                        await self._handle_ws_message(msg)

            except (ConnectionClosedError, ConnectionClosedOK):
                logger.warning("WebSocket fermé — reconnexion dans {}s".format(delay))
            except Exception as e:
                logger.error(f"WebSocket erreur: {e} — reconnexion dans {delay}s")

            # Marque déconnecté
            for s in ASSET_SYMBOLS:
                self.states[s].is_connected = False

            if self._running:
                await asyncio.sleep(delay)
                delay = min(delay * 2, self._max_reconnect)

    async def _handle_ws_message(self, raw: str):
        """Parse et traite un message WebSocket TwelveData."""
        try:
            data = json.loads(raw)
        except Exception:
            return

        event = data.get("event")

        if event == "price":
            symbol_td = data.get("symbol", "")
            # Retrouve notre symbole interne
            symbol = next(
                (s for s, cfg in ASSETS.items() if cfg["td_symbol"] == symbol_td),
                None
            )
            if not symbol:
                return

            price = float(data.get("price", 0))
            if price <= 0:
                return

            ts = datetime.fromtimestamp(
                data.get("timestamp", time.time()), tz=timezone.utc
            )
            tick = Tick(
                symbol=symbol,
                price=price,
                timestamp=ts,
                bid=float(data.get("bid", price)),
                ask=float(data.get("ask", price)),
            )

            # Met à jour l'état
            state = self.states[symbol]
            state.last_tick = tick
            state.tick_count += 1
            self._last_price[symbol] = price

            # Ingère dans le builder
            completed = self.builders[symbol].feed(tick)

            # Callbacks tick
            for cb in self._tick_cbs:
                try:
                    asyncio.create_task(cb(tick))
                except Exception:
                    pass

            # Callbacks bougies fermées
            for tf_sec, candle in completed.items():
                if candle is not None:
                    for cb in self._candle_cbs:
                        try:
                            asyncio.create_task(cb(symbol, tf_sec, candle))
                        except Exception:
                            pass

        elif event == "subscribe-status":
            logger.info(f"WS subscribe-status: {data.get('status')}")

        elif event == "heartbeat":
            pass  # TwelveData heartbeat, ignoré

    # ── Heartbeat REST (fallback prix si WS lent) ─────────────────────────────

    async def _heartbeat(self):
        """Rafraîchit les prix via REST toutes les 10s si WS inactif."""
        while self._running:
            await asyncio.sleep(10)
            for symbol in ASSET_SYMBOLS:
                state = self.states[symbol]
                # Si pas de tick depuis 15s
                if state.last_tick:
                    age = (datetime.now(timezone.utc) - state.last_tick.timestamp).total_seconds()
                    if age < 15:
                        continue

                try:
                    price = await fetch_current_price(self._session, symbol)
                    if price:
                        now = datetime.now(timezone.utc)
                        tick = Tick(symbol=symbol, price=price, timestamp=now)
                        state.last_tick = tick
                        self._last_price[symbol] = price
                        completed = self.builders[symbol].feed(tick)
                        for cb in self._tick_cbs:
                            asyncio.create_task(cb(tick))
                except Exception:
                    pass


# Singleton global
market_data = MarketDataManager()
