"""
RSKQxTrade — FastAPI Backend
REST API + WebSocket pour le frontend Telegram Mini App
"""
import asyncio
import json
import logging
import time
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from typing import Dict, List, Optional

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from config import ASSET_SYMBOLS, EXPIRATIONS, APP_URL, WEBAPP_URL
from models.schemas import SignalResponse, AnalysisRequest, MultiAnalysisRequest
from core.market_data import market_data
from core.signal_engine import SignalEngine

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(name)s | %(levelname)s | %(message)s"
)
logger = logging.getLogger("api")

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# INIT
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

engine = SignalEngine(market_data)

# WebSocket connections actives
ws_clients: List[WebSocket] = []


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup / shutdown du serveur."""
    logger.info("🚀 RSKQxTrade backend starting...")
    await market_data.start()
    # Abonne le broadcaster aux nouveaux ticks
    market_data.on_tick(broadcast_tick)
    logger.info("✅ Backend prêt")
    yield
    logger.info("🛑 Shutdown...")
    await market_data.stop()


app = FastAPI(
    title="RSKQxTrade API",
    description="Trading signal engine for binary options",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# HEALTH
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@app.get("/")
async def root():
    return {"status": "ok", "service": "RSKQxTrade", "version": "1.0.0"}


@app.get("/health")
async def health():
    status = {}
    for sym in ASSET_SYMBOLS:
        state = market_data.states[sym]
        status[sym] = {
            "connected":  state.is_connected,
            "price":      market_data.get_price(sym),
            "tick_count": state.tick_count,
            "ready":      market_data.is_ready(sym),
        }
    return {
        "status": "healthy",
        "assets": status,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# SIGNAL ENDPOINTS
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@app.get("/signal/{asset}", response_model=SignalResponse)
async def get_signal(
    asset: str,
    expiry: str = Query("1m", enum=EXPIRATIONS),
):
    """
    Analyse un actif et retourne le signal CALL/PUT/NO TRADE.
    asset : EUR/USD, BTC/USD, GBP/USD, XAU/USD, USD/JPY
    expiry: 1m, 2m, 3m, 5m, 10m, 15m
    """
    asset = asset.upper().replace("-", "/")
    if asset not in ASSET_SYMBOLS:
        raise HTTPException(400, f"Actif inconnu. Disponibles: {ASSET_SYMBOLS}")
    if expiry not in EXPIRATIONS:
        raise HTTPException(400, f"Expiration invalide. Disponibles: {EXPIRATIONS}")

    try:
        signal = await engine.analyze(asset, expiry)
        return signal
    except Exception as e:
        logger.error(f"get_signal {asset}: {e}")
        raise HTTPException(500, f"Erreur analyse: {str(e)}")


@app.post("/signals", response_model=Dict[str, SignalResponse])
async def get_all_signals(req: MultiAnalysisRequest):
    """Analyse plusieurs actifs en parallèle."""
    assets = [a.upper().replace("-", "/") for a in req.assets]
    unknown = [a for a in assets if a not in ASSET_SYMBOLS]
    if unknown:
        raise HTTPException(400, f"Actifs inconnus: {unknown}")

    results = await asyncio.gather(
        *[engine.analyze(a, req.expiry) for a in assets],
        return_exceptions=True
    )
    out = {}
    for a, r in zip(assets, results):
        if isinstance(r, Exception):
            logger.error(f"signals/{a}: {r}")
        else:
            out[a] = r
    return out


@app.get("/scan", response_model=Dict[str, SignalResponse])
async def scan_all(expiry: str = Query("1m", enum=EXPIRATIONS)):
    """Scanne les 5 actifs et retourne tous les signaux."""
    return await engine.analyze_all(expiry)


@app.get("/price/{asset}")
async def get_price(asset: str):
    """Prix actuel d'un actif."""
    asset = asset.upper().replace("-", "/")
    if asset not in ASSET_SYMBOLS:
        raise HTTPException(400, "Actif inconnu")
    price = market_data.get_price(asset)
    return {
        "asset": asset,
        "price": price,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


@app.get("/prices")
async def get_all_prices():
    """Prix de tous les actifs."""
    return {
        sym: {
            "price": market_data.get_price(sym),
            "connected": market_data.states[sym].is_connected,
        }
        for sym in ASSET_SYMBOLS
    }


@app.get("/assets")
async def get_assets():
    """Liste des actifs et expirations disponibles."""
    from config import ASSETS
    return {
        "assets": list(ASSETS.keys()),
        "expirations": EXPIRATIONS,
        "timeframes": list(__import__("config").TIMEFRAMES.keys()),
    }


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# WEBSOCKET — push temps réel vers le frontend
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@app.websocket("/ws")
async def websocket_endpoint(ws: WebSocket):
    """
    WebSocket pour le frontend Mini App.
    Le client envoie: {"action": "subscribe", "assets": [...], "expiry": "1m"}
    Le serveur push: ticks prix + signaux en temps réel
    """
    await ws.accept()
    ws_clients.append(ws)
    logger.info(f"WS client connecté ({len(ws_clients)} total)")

    subscribed_assets = ASSET_SYMBOLS.copy()
    current_expiry    = "1m"

    try:
        # Envoie l'état initial
        prices = {s: market_data.get_price(s) for s in ASSET_SYMBOLS}
        await ws.send_json({
            "type":   "init",
            "prices": prices,
            "assets": ASSET_SYMBOLS,
            "expiry_options": EXPIRATIONS,
        })

        while True:
            try:
                raw = await asyncio.wait_for(ws.receive_text(), timeout=1.0)
                msg = json.loads(raw)
                action = msg.get("action")

                if action == "subscribe":
                    subscribed_assets = msg.get("assets", ASSET_SYMBOLS)
                    current_expiry    = msg.get("expiry", "1m")
                    await ws.send_json({"type": "subscribed",
                                       "assets": subscribed_assets,
                                       "expiry": current_expiry})

                elif action == "analyze":
                    asset  = msg.get("asset", "EUR/USD")
                    expiry = msg.get("expiry", current_expiry)
                    if asset in ASSET_SYMBOLS:
                        sig = await engine.analyze(asset, expiry)
                        await ws.send_json({"type": "signal", **sig.model_dump()})

                elif action == "scan":
                    expiry  = msg.get("expiry", current_expiry)
                    signals = await engine.analyze_all(expiry)
                    await ws.send_json({
                        "type":    "scan_result",
                        "signals": {k: v.model_dump() for k, v in signals.items()},
                    })

                elif action == "ping":
                    await ws.send_json({"type": "pong", "ts": time.time()})

            except asyncio.TimeoutError:
                # Envoie un ping keepalive
                try:
                    await ws.send_json({"type": "heartbeat", "ts": time.time()})
                except Exception:
                    break
            except json.JSONDecodeError:
                pass

    except WebSocketDisconnect:
        pass
    except Exception as e:
        logger.error(f"WS error: {e}")
    finally:
        if ws in ws_clients:
            ws_clients.remove(ws)
        logger.info(f"WS client déconnecté ({len(ws_clients)} restants)")


async def broadcast_tick(tick):
    """Diffuse les ticks de prix à tous les clients WS connectés."""
    if not ws_clients:
        return
    msg = json.dumps({
        "type":   "tick",
        "symbol": tick.symbol,
        "price":  tick.price,
        "ts":     tick.timestamp.isoformat(),
    })
    dead = []
    for ws in ws_clients:
        try:
            await ws.send_text(msg)
        except Exception:
            dead.append(ws)
    for ws in dead:
        if ws in ws_clients:
            ws_clients.remove(ws)
