"""
RSKQxTrade — Modèles de données
Schémas Pydantic pour toutes les structures
"""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, List, Optional, Literal
from pydantic import BaseModel, Field


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# OHLCV
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@dataclass
class Candle:
    timestamp: datetime
    open:   float
    high:   float
    low:    float
    close:  float
    volume: float = 0.0

    @property
    def body(self) -> float:
        return abs(self.close - self.open)

    @property
    def upper_wick(self) -> float:
        return self.high - max(self.open, self.close)

    @property
    def lower_wick(self) -> float:
        return min(self.open, self.close) - self.low

    @property
    def is_bullish(self) -> bool:
        return self.close >= self.open

    @property
    def is_bearish(self) -> bool:
        return self.close < self.open

    @property
    def range(self) -> float:
        return self.high - self.low


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# TICK (prix en temps réel)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@dataclass
class Tick:
    symbol:    str
    price:     float
    timestamp: datetime
    bid:       Optional[float] = None
    ask:       Optional[float] = None

    @property
    def spread(self) -> Optional[float]:
        if self.bid and self.ask:
            return self.ask - self.bid
        return None


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# FEATURES PAR COUCHE
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@dataclass
class TrendFeatures:
    ema9:         float
    ema20:        float
    ema50:        float
    vwap:         float
    ema_cross_9_20:  int   # +1 bull, -1 bear, 0 neutral
    ema_cross_20_50: int
    ema9_slope:   float   # % change per bar
    ema20_slope:  float
    price_vs_vwap: float  # +1 above, -1 below


@dataclass
class MomentumFeatures:
    rsi:          float
    rsi_slope:    float   # direction du RSI
    macd:         float
    macd_signal:  float
    macd_hist:    float
    macd_cross:   int     # +1 bullish cross, -1 bearish
    stoch_k:      float
    stoch_d:      float
    stoch_zone:   int     # +1 oversold, -1 overbought, 0 neutral


@dataclass
class VolatilityFeatures:
    atr:              float
    atr_pct:          float   # ATR / price * 100
    bb_upper:         float
    bb_lower:         float
    bb_mid:           float
    bb_width:         float   # (upper - lower) / mid
    bb_position:      float   # 0=lower, 1=upper
    is_high_vol:      bool
    is_squeeze:       bool    # BB très serré = breakout imminent


@dataclass
class PriceActionFeatures:
    support_levels:     List[float]
    resistance_levels:  List[float]
    nearest_support:    float
    nearest_resistance: float
    dist_to_support:    float   # en %
    dist_to_resistance: float   # en %
    breakout_signal:    int     # +1 haussier, -1 baissier, 0 rien
    is_fakeout:         bool
    upper_wick_ratio:   float   # wick / range
    lower_wick_ratio:   float
    wick_pressure:      int     # +1 bull (long lower wick), -1 bear


@dataclass
class MicrostructureFeatures:
    price_speed:       float   # vitesse changement prix (pip/s)
    price_acceleration: float  # accélération
    candle_strength:   float   # body / range ratio
    candle_direction:  int     # +1 bull, -1 bear
    volume_ratio:      float   # volume actuel / volume moyen
    volume_pressure:   int     # +1 achat, -1 vente
    consecutive_bulls: int
    consecutive_bears: int


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# RÉSULTAT PAR TIMEFRAME
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@dataclass
class TimeframeSignal:
    timeframe:      str
    direction:      Literal["CALL", "PUT", "NEUTRAL"]
    score:          float    # -1.0 à +1.0 (négatif = PUT, positif = CALL)
    confidence:     float    # 0.0 à 1.0
    trend:          TrendFeatures
    momentum:       MomentumFeatures
    volatility:     VolatilityFeatures
    price_action:   PriceActionFeatures
    microstructure: MicrostructureFeatures
    layer_scores:   Dict[str, float]  # score par couche


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# SIGNAL FINAL (API output)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

class SignalResponse(BaseModel):
    asset:          str
    direction:      Literal["CALL", "PUT", "NO TRADE"]
    probability:    float = Field(..., ge=0, le=100, description="Probabilité en %")
    confidence:     Literal["HIGH", "MEDIUM", "LOW", "INSUFFICIENT"]
    expiry:         str
    target_time:    str   # heure d'expiration après latence
    reason:         str
    current_price:  float
    tf_breakdown:   Dict[str, str]  # résumé par TF
    layer_scores:   Dict[str, float]
    generated_at:   str
    signal_age_ok:  bool  # True si le signal est encore frais


class AnalysisRequest(BaseModel):
    asset:  str
    expiry: str = "1m"


class MultiAnalysisRequest(BaseModel):
    assets: List[str]
    expiry: str = "1m"


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# ÉTAT DU MARCHÉ
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@dataclass
class MarketState:
    symbol:        str
    last_tick:     Optional[Tick]           = None
    candles:       Dict[str, List[Candle]]  = field(default_factory=dict)  # par TF
    last_signal:   Optional[SignalResponse] = None
    signal_ts:     Optional[datetime]       = None
    is_connected:  bool                     = False
    tick_count:    int                      = 0
