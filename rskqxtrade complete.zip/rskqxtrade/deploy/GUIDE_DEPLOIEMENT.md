# RSKQxTrade — Guide de Déploiement
## Vercel + Telegram Mini App

---

## 1. STRUCTURE DU PROJET

```
rskqxtrade/
├── backend/
│   ├── main.py               ← Point d'entrée FastAPI
│   ├── config.py             ← Config + clés API
│   ├── requirements.txt      ← Dépendances Python
│   ├── telegram_bot.py       ← Bot Telegram
│   ├── core/
│   │   ├── market_data.py    ← WebSocket TwelveData
│   │   ├── features.py       ← Calcul indicateurs
│   │   └── signal_engine.py  ← Moteur de signal
│   ├── models/
│   │   └── schemas.py        ← Modèles Pydantic
│   └── api/
│       └── routes.py         ← Endpoints FastAPI
├── frontend/
│   └── src/
│       └── index.html        ← Telegram Mini App
└── deploy/
    └── vercel.json           ← Config Vercel
```

---

## 2. DÉPLOIEMENT VERCEL

### Étape 1 — Préparer le repo GitHub
```bash
git init
git add .
git commit -m "initial: RSKQxTrade"
git remote add origin https://github.com/TON_USER/rskqxtrade.git
git push -u origin main
```

### Étape 2 — Créer le projet Vercel
1. Va sur vercel.com → New Project
2. Importe ton repo GitHub
3. **Project Name** : `rskqxtradebot`
4. **Framework Preset** : Other
5. **Root Directory** : `.` (racine)

### Étape 3 — Variables d'environnement Vercel
Dans Settings → Environment Variables, ajoute :

| Variable | Valeur |
|---|---|
| `TWELVEDATA_API_KEY` | `c3c307ede4dd401b84a4493efd4f9f04` |
| `TELEGRAM_BOT_TOKEN` | `8788118641:AAHt37OfJqVvHiB3f_BTZiLc59L9tiztJXk` |
| `APP_URL` | `https://rskqxtradebot.vercel.app` |

### Étape 4 — Déployer
```bash
vercel --prod
# ou via l'interface : cliquer Deploy
```

### Étape 5 — Copier vercel.json
```bash
cp deploy/vercel.json vercel.json
```

---

## 3. CONFIGURATION TELEGRAM

### Définir le webhook
```bash
curl -X POST "https://api.telegram.org/bot8788118641:AAHt37OfJqVvHiB3f_BTZiLc59L9tiztJXk/setWebhook" \
  -H "Content-Type: application/json" \
  -d '{"url": "https://rskqxtradebot.vercel.app/webhook/telegram"}'
```

### Définir la Mini App (via BotFather)
```
/newapp           → Crée une nouvelle Mini App
URL               → https://rskqxtradebot.vercel.app/app
Titre             → RSKQxTrade
Description       → Signal engine multi-timeframe
```

Ou via `/setmenubutton` dans BotFather pour afficher le bouton directement.

### Commandes BotFather (`/setcommands`)
```
start - Menu principal
signal - Signal pour un actif
scan - Scan de tous les actifs
expiry - Changer l'expiration
prices - Prix actuels
app - Ouvrir la Mini App
help - Aide
```

---

## 4. TEST LOCAL (Replit ou machine locale)

### Installation
```bash
cd backend
pip install -r requirements.txt
```

### Variables d'environnement locales
Crée un fichier `.env` dans `backend/` :
```env
TWELVEDATA_API_KEY=c3c307ede4dd401b84a4493efd4f9f04
TELEGRAM_BOT_TOKEN=8788118641:AAHt37OfJqVvHiB3f_BTZiLc59L9tiztJXk
APP_URL=http://localhost:8000
DEBUG=true
```

### Lancement
```bash
cd backend
python main.py
```

Le bot démarre en **polling** automatiquement si le webhook échoue (mode local).

### Test API
```bash
# Health check
curl http://localhost:8000/health

# Signal EUR/USD 1m
curl "http://localhost:8000/signal/EUR-USD?expiry=1m"

# Scan tous les actifs
curl "http://localhost:8000/scan?expiry=5m"

# Prix actuels
curl http://localhost:8000/prices
```

### Mini App locale
Ouvre `frontend/src/index.html` dans un navigateur.
Change `API_BASE` dans le script JS si besoin.

---

## 5. ENDPOINTS API

| Méthode | Route | Description |
|---|---|---|
| GET | `/` | Status |
| GET | `/health` | État des connexions |
| GET | `/signal/{asset}?expiry=1m` | Signal pour un actif |
| POST | `/signals` | Signaux multiples |
| GET | `/scan?expiry=1m` | Scan de tous les actifs |
| GET | `/price/{asset}` | Prix actuel |
| GET | `/prices` | Tous les prix |
| GET | `/assets` | Liste actifs/expirations |
| WS | `/ws` | WebSocket temps réel |
| POST | `/webhook/telegram` | Webhook bot Telegram |

### Exemple de réponse `/signal`
```json
{
  "asset": "EUR/USD",
  "direction": "CALL",
  "probability": 72.4,
  "confidence": "MEDIUM",
  "expiry": "1m",
  "target_time": "14:32:18 UTC",
  "reason": "CALL confirmé sur 1m, 2m, 5m | Signal dominant: momentum RSI/MACD | Probabilité: 72%",
  "current_price": 1.08432,
  "tf_breakdown": {
    "5s":  "🔵 CALL (+0.42)",
    "15s": "🔵 CALL (+0.38)",
    "30s": "⚪ NEUTRE",
    "1m":  "🔵 CALL (+0.51)",
    "2m":  "🔵 CALL (+0.47)",
    "5m":  "⚪ NEUTRE"
  },
  "layer_scores": {
    "trend": 0.45,
    "momentum": 0.62,
    "volatility": 0.18,
    "price_action": 0.31,
    "microstructure": 0.55
  },
  "generated_at": "14:31:15 UTC",
  "signal_age_ok": true
}
```

---

## 6. ARCHITECTURE TEMPS RÉEL

```
TwelveData WS ──→ MarketDataManager ──→ CandleBuilder
                        │                     │
                        ▼                     ▼
                   Last Tick           Candles par TF
                        │                     │
                        └──────────┬──────────┘
                                   ▼
                            SignalEngine
                                   │
                    ┌──────────────┼──────────────┐
                    ▼              ▼               ▼
               features.py    Per-TF          Fusion MTF
              (indicateurs)   analysis      (score pondéré)
                                   │
                        ┌──────────┴──────────┐
                        ▼                     ▼
                   FastAPI REST          WebSocket
                   /signal/{a}           /ws → push
                        │                     │
                        └──────────┬──────────┘
                                   ▼
                            Telegram Bot
                         (/signal, /scan)
                                   │
                                   ▼
                          Mini App Frontend
                       (index.html via /app)
```

---

## 7. COMMANDES TELEGRAM

| Commande | Description |
|---|---|
| `/start` | Menu principal + bouton Mini App |
| `/signal EUR/USD 5m` | Signal détaillé avec breakdown TF |
| `/scan` | Scan des 5 actifs simultanément |
| `/expiry 5m` | Définit l'expiration par défaut |
| `/prices` | Prix temps réel de tous les actifs |
| `/app` | Ouvre la Telegram Mini App |
| `/help` | Aide complète |

---

## 8. DÉPANNAGE

### Bot ne répond pas
```bash
# Vérifie le webhook
curl "https://api.telegram.org/bot<TOKEN>/getWebhookInfo"
```

### TwelveData WebSocket déconnecté
- Le système reconnecte automatiquement avec backoff exponentiel
- En cas d'échec, le heartbeat REST prend le relais toutes les 10s

### "Données insuffisantes" au démarrage
- Normal : attends 30-60 secondes que l'historique soit chargé
- Le bootstrap charge 150 bougies par actif/TF au démarrage

### Limite API TwelveData (plan gratuit)
- Le plan gratuit = 8 requêtes/min REST
- WebSocket = illimité (prix en temps réel)
- Si limité : réduis `outputsize` dans `fetch_historical`

---

## 9. MISE À JOUR DES CLÉS API

Dans Vercel Dashboard → Settings → Environment Variables :
- Modifie les valeurs → Redéploie automatiquement

En local, édite `.env` puis relance `python main.py`.

---

⚠️ **IMPORTANT** : Change tes clés API publiques immédiatement.
Elles ont été exposées dans ce chat. Va sur :
- TwelveData → dashboard → API keys → Regenerate
- BotFather → /revoke pour ton bot
