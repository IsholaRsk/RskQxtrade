"""
RSKQxTrade — Feature Engineering
Calcul de tous les indicateurs techniques sur les bougies OHLCV
EMA, VWAP, RSI, MACD, StochRSI, ATR, Bollinger, S/R, microstructure
"""
import math
from typing import List, Optional, Tuple, Dict
from models.schemas import (
    Candle, TrendFeatures, MomentumFeatures, VolatilityFeatures,
    PriceActionFeatures, MicrostructureFeatures,
)


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# PRIMITIVES
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def closes(candles: List[Candle]) -> List[float]:
    return [c.close for c in candles]

def highs(candles: List[Candle]) -> List[float]:
    return [c.high for c in candles]

def lows(candles: List[Candle]) -> List[float]:
    return [c.low for c in candles]

def volumes(candles: List[Candle]) -> List[float]:
    return [c.volume for c in candles]


def ema(values: List[float], period: int) -> List[float]:
    """Calcule l'EMA sur une série."""
    if len(values) < period:
        return []
    k = 2.0 / (period + 1)
    result = [sum(values[:period]) / period]
    for v in values[period:]:
        result.append(v * k + result[-1] * (1 - k))
    return result


def sma(values: List[float], period: int) -> List[float]:
    if len(values) < period:
        return []
    return [sum(values[i:i+period]) / period for i in range(len(values) - period + 1)]


def rsi(values: List[float], period: int = 14) -> Optional[float]:
    """RSI de Wilder sur les `period` dernières bougies."""
    if len(values) < period + 1:
        return None
    deltas = [values[i+1] - values[i] for i in range(len(values)-1)]
    gains  = [max(d, 0) for d in deltas[-period:]]
    losses = [abs(min(d, 0)) for d in deltas[-period:]]
    avg_gain = sum(gains) / period
    avg_loss = sum(losses) / period
    if avg_loss == 0:
        return 100.0
    rs = avg_gain / avg_loss
    return round(100 - 100 / (1 + rs), 2)


def rsi_series(values: List[float], period: int = 14) -> List[float]:
    """RSI série complète."""
    result = []
    for i in range(period, len(values)):
        result.append(rsi(values[:i+1], period) or 50.0)
    return result


def macd(values: List[float], fast=12, slow=26, signal=9) -> Tuple[float, float, float]:
    """Retourne (macd_line, signal_line, histogram)."""
    if len(values) < slow + signal:
        return 0.0, 0.0, 0.0
    ema_fast   = ema(values, fast)
    ema_slow   = ema(values, slow)
    n = min(len(ema_fast), len(ema_slow))
    macd_line  = [ema_fast[-n+i] - ema_slow[i] for i in range(n)]
    signal_line = ema(macd_line, signal)
    if not signal_line:
        return macd_line[-1], 0.0, macd_line[-1]
    hist = macd_line[-1] - signal_line[-1]
    return round(macd_line[-1], 6), round(signal_line[-1], 6), round(hist, 6)


def stochastic_rsi(values: List[float], rsi_period=14, stoch_period=14,
                   k_smooth=3, d_smooth=3) -> Tuple[float, float]:
    """Calcule le StochRSI (K, D)."""
    rsi_vals = rsi_series(values, rsi_period)
    if len(rsi_vals) < stoch_period:
        return 50.0, 50.0

    stoch_k_raw = []
    for i in range(stoch_period - 1, len(rsi_vals)):
        window = rsi_vals[i - stoch_period + 1: i + 1]
        mn, mx = min(window), max(window)
        if mx == mn:
            stoch_k_raw.append(50.0)
        else:
            stoch_k_raw.append((rsi_vals[i] - mn) / (mx - mn) * 100)

    k_smooth_vals = sma(stoch_k_raw, k_smooth) if len(stoch_k_raw) >= k_smooth else stoch_k_raw
    d_smooth_vals = sma(k_smooth_vals, d_smooth) if len(k_smooth_vals) >= d_smooth else k_smooth_vals

    k = round(k_smooth_vals[-1], 2) if k_smooth_vals else 50.0
    d = round(d_smooth_vals[-1], 2) if d_smooth_vals else 50.0
    return k, d


def atr(candles: List[Candle], period: int = 14) -> Optional[float]:
    """Average True Range."""
    if len(candles) < period + 1:
        return None
    trs = []
    for i in range(1, len(candles)):
        c = candles[i]
        prev_close = candles[i-1].close
        tr = max(c.high - c.low, abs(c.high - prev_close), abs(c.low - prev_close))
        trs.append(tr)
    if len(trs) < period:
        return None
    atr_vals = [sum(trs[:period]) / period]
    for tr in trs[period:]:
        atr_vals.append((atr_vals[-1] * (period - 1) + tr) / period)
    return round(atr_vals[-1], 6)


def bollinger_bands(values: List[float], period: int = 20,
                    std_dev: float = 2.0) -> Optional[Tuple[float, float, float]]:
    """Retourne (upper, mid, lower)."""
    if len(values) < period:
        return None
    window = values[-period:]
    mid = sum(window) / period
    variance = sum((x - mid) ** 2 for x in window) / period
    std = math.sqrt(variance)
    return round(mid + std_dev * std, 6), round(mid, 6), round(mid - std_dev * std, 6)


def vwap(candles: List[Candle]) -> Optional[float]:
    """VWAP intraday (reset quotidien)."""
    if not candles:
        return None
    total_vol   = sum(c.volume for c in candles)
    if total_vol == 0:
        # Si pas de volume (forex), utilise une moyenne pondérée par range
        prices = [(c.high + c.low + c.close) / 3 for c in candles]
        return round(sum(prices) / len(prices), 6)
    total_pv = sum(((c.high + c.low + c.close) / 3) * c.volume for c in candles)
    return round(total_pv / total_vol, 6)


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# SUPPORT / RESISTANCE
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def find_sr_levels(candles: List[Candle], lookback: int = 50,
                   tolerance: float = 0.001) -> Tuple[List[float], List[float]]:
    """
    Identifie les niveaux support/résistance par pivots.
    Returns: (supports, resistances)
    """
    if len(candles) < 5:
        return [], []

    recent = candles[-lookback:]
    pivots_high = []
    pivots_low  = []

    for i in range(2, len(recent) - 2):
        h = recent[i].high
        l = recent[i].low
        # Pivot haut
        if h >= recent[i-1].high and h >= recent[i-2].high and \
           h >= recent[i+1].high and h >= recent[i+2].high:
            pivots_high.append(h)
        # Pivot bas
        if l <= recent[i-1].low and l <= recent[i-2].low and \
           l <= recent[i+1].low and l <= recent[i+2].low:
            pivots_low.append(l)

    def cluster(levels: List[float]) -> List[float]:
        if not levels:
            return []
        levels = sorted(levels)
        clusters = [[levels[0]]]
        for v in levels[1:]:
            if abs(v - clusters[-1][-1]) / max(clusters[-1][-1], 1e-10) <= tolerance:
                clusters[-1].append(v)
            else:
                clusters.append([v])
        return [round(sum(c) / len(c), 6) for c in clusters]

    return cluster(pivots_low), cluster(pivots_high)


def detect_breakout(candles: List[Candle], supports: List[float],
                    resistances: List[float]) -> Tuple[int, bool]:
    """
    Détecte un breakout ou fakeout.
    Returns: (signal: +1/-1/0, is_fakeout: bool)
    """
    if not candles or (not supports and not resistances):
        return 0, False

    last   = candles[-1]
    prev   = candles[-2] if len(candles) >= 2 else last
    price  = last.close
    signal = 0
    fakeout = False

    # Breakout résistance
    for r in resistances:
        if prev.close <= r and price > r:
            signal = 1
            # Fakeout si la wick supérieure est longue et fermeture en dessous
            if last.upper_wick > last.body * 1.5 and last.close < r:
                fakeout = True
                signal  = -1
            break

    # Breakout support
    if signal == 0:
        for s in supports:
            if prev.close >= s and price < s:
                signal = -1
                if last.lower_wick > last.body * 1.5 and last.close > s:
                    fakeout = True
                    signal  = 1
                break

    return signal, fakeout


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# FEATURE EXTRACTORS
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def extract_trend(candles: List[Candle]) -> Optional[TrendFeatures]:
    if len(candles) < 55:
        return None

    cl = closes(candles)
    e9  = ema(cl, 9)
    e20 = ema(cl, 20)
    e50 = ema(cl, 50)

    if not e9 or not e20 or not e50:
        return None

    price = cl[-1]
    _vwap = vwap(candles[-50:]) or price

    # Slopes (% change per bar over last 3)
    def slope(series: List[float], n: int = 3) -> float:
        if len(series) < n:
            return 0.0
        return (series[-1] - series[-n]) / max(abs(series[-n]), 1e-10) * 100

    cross_9_20  = 1 if e9[-1] > e20[-1] else (-1 if e9[-1] < e20[-1] else 0)
    cross_20_50 = 1 if e20[-1] > e50[-1] else (-1 if e20[-1] < e50[-1] else 0)

    return TrendFeatures(
        ema9=round(e9[-1], 6),
        ema20=round(e20[-1], 6),
        ema50=round(e50[-1], 6),
        vwap=round(_vwap, 6),
        ema_cross_9_20=cross_9_20,
        ema_cross_20_50=cross_20_50,
        ema9_slope=round(slope(e9), 4),
        ema20_slope=round(slope(e20), 4),
        price_vs_vwap=1 if price > _vwap else -1,
    )


def extract_momentum(candles: List[Candle]) -> Optional[MomentumFeatures]:
    if len(candles) < 40:
        return None

    cl = closes(candles)
    _rsi   = rsi(cl, 14) or 50.0
    _rsi_p = rsi(cl[:-1], 14) or 50.0
    _macd, _signal, _hist = macd(cl)
    _macd_p, _signal_p, _ = macd(cl[:-1])
    k, d = stochastic_rsi(cl)

    macd_cross = 0
    if _macd > _signal and _macd_p <= _signal_p:
        macd_cross = 1   # bullish cross
    elif _macd < _signal and _macd_p >= _signal_p:
        macd_cross = -1  # bearish cross

    stoch_zone = 0
    if k < 20 and d < 20:
        stoch_zone = 1   # oversold → bull
    elif k > 80 and d > 80:
        stoch_zone = -1  # overbought → bear

    return MomentumFeatures(
        rsi=_rsi,
        rsi_slope=round(_rsi - _rsi_p, 3),
        macd=_macd,
        macd_signal=_signal,
        macd_hist=_hist,
        macd_cross=macd_cross,
        stoch_k=k,
        stoch_d=d,
        stoch_zone=stoch_zone,
    )


def extract_volatility(candles: List[Candle]) -> Optional[VolatilityFeatures]:
    if len(candles) < 25:
        return None

    cl   = closes(candles)
    _atr = atr(candles, 14)
    if _atr is None:
        return None

    price  = cl[-1]
    atr_pct = _atr / price * 100

    bb = bollinger_bands(cl, 20, 2.0)
    if bb is None:
        return None
    upper, mid, lower = bb
    width   = (upper - lower) / max(mid, 1e-10)
    bb_pos  = (price - lower) / max(upper - lower, 1e-10)

    # Squeeze : BB très serré (< 0.5% de la moyenne)
    is_squeeze = width < 0.005
    # Haute vol : ATR > 2.5× moyenne des 10 derniers ATR
    atrs_recent = [atr(candles[:i], 14) for i in range(len(candles)-9, len(candles)+1)]
    atrs_recent = [a for a in atrs_recent if a]
    avg_atr = sum(atrs_recent) / len(atrs_recent) if atrs_recent else _atr
    is_high_vol = _atr > avg_atr * 2.5

    return VolatilityFeatures(
        atr=_atr,
        atr_pct=round(atr_pct, 4),
        bb_upper=upper,
        bb_lower=lower,
        bb_mid=mid,
        bb_width=round(width, 4),
        bb_position=round(min(max(bb_pos, 0), 1), 3),
        is_high_vol=is_high_vol,
        is_squeeze=is_squeeze,
    )


def extract_price_action(candles: List[Candle]) -> Optional[PriceActionFeatures]:
    if len(candles) < 10:
        return None

    price    = candles[-1].close
    supports, resistances = find_sr_levels(candles, lookback=60)

    nearest_sup = max([s for s in supports if s < price], default=price * 0.998)
    nearest_res = min([r for r in resistances if r > price], default=price * 1.002)

    dist_sup = abs(price - nearest_sup) / price * 100
    dist_res = abs(nearest_res - price) / price * 100

    breakout_sig, fakeout = detect_breakout(candles, supports, resistances)

    # Analyse des wicks (3 dernières bougies)
    last = candles[-1]
    rng  = max(last.range, 1e-10)
    uw   = round(last.upper_wick / rng, 3)
    lw   = round(last.lower_wick / rng, 3)
    # Long lower wick = pression acheteuse
    wick_pressure = 1 if lw > 0.4 and uw < 0.2 else \
                   (-1 if uw > 0.4 and lw < 0.2 else 0)

    return PriceActionFeatures(
        support_levels=supports[-3:],
        resistance_levels=resistances[:3],
        nearest_support=nearest_sup,
        nearest_resistance=nearest_res,
        dist_to_support=round(dist_sup, 4),
        dist_to_resistance=round(dist_res, 4),
        breakout_signal=breakout_sig,
        is_fakeout=fakeout,
        upper_wick_ratio=uw,
        lower_wick_ratio=lw,
        wick_pressure=wick_pressure,
    )


def extract_microstructure(candles: List[Candle]) -> Optional[MicrostructureFeatures]:
    if len(candles) < 5:
        return None

    recent  = candles[-5:]
    last    = candles[-1]
    prev    = candles[-2]

    # Vitesse (pip/sec approximatif)
    dt_secs = (last.timestamp - prev.timestamp).total_seconds()
    if dt_secs <= 0:
        dt_secs = 60
    price_speed = abs(last.close - prev.close) / dt_secs

    # Accélération
    if len(candles) >= 3:
        pprev = candles[-3]
        dt2   = (prev.timestamp - pprev.timestamp).total_seconds()
        speed_prev = abs(prev.close - pprev.close) / max(dt2, 1)
        acceleration = price_speed - speed_prev
    else:
        acceleration = 0.0

    # Force de la bougie
    rng = max(last.range, 1e-10)
    candle_strength  = round(last.body / rng, 3)
    candle_direction = 1 if last.is_bullish else -1

    # Volume pressure
    vols = [c.volume for c in recent]
    avg_vol = sum(vols[:-1]) / max(len(vols) - 1, 1) if len(vols) > 1 else vols[-1]
    vol_ratio = last.volume / max(avg_vol, 1e-10)
    # Si volume > moyenne + direction claire → pression directionnelle
    vol_pressure = 0
    if vol_ratio > 1.3:
        vol_pressure = 1 if last.is_bullish else -1

    # Consécutives
    bulls = bears = 0
    for c in reversed(candles[-10:]):
        if c.is_bullish:
            if bears > 0: break
            bulls += 1
        else:
            if bulls > 0: break
            bears += 1

    return MicrostructureFeatures(
        price_speed=round(price_speed, 8),
        price_acceleration=round(acceleration, 8),
        candle_strength=candle_strength,
        candle_direction=candle_direction,
        volume_ratio=round(vol_ratio, 3),
        volume_pressure=vol_pressure,
        consecutive_bulls=bulls,
        consecutive_bears=bears,
    )
