"""
RSKQxTrade — Signal Engine
Moteur de décision multi-couches, multi-timeframes
Fusion → CALL / PUT / NO TRADE + probabilité + confiance
"""
import asyncio
import logging
import time
from datetime import datetime, timezone, timedelta
from typing import Dict, List, Optional, Tuple

from config import (
    TIMEFRAMES, SIGNAL_CONFIG, LAYER_WEIGHTS, INDICATOR_WEIGHTS, EXPIRY_SECONDS,
)
from models.schemas import (
    Candle, TimeframeSignal, SignalResponse,
    TrendFeatures, MomentumFeatures, VolatilityFeatures,
    PriceActionFeatures, MicrostructureFeatures,
)
from core.features import (
    extract_trend, extract_momentum, extract_volatility,
    extract_price_action, extract_microstructure,
)

logger = logging.getLogger("signal_engine")


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# SCORERS PAR COUCHE
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def score_trend(t: TrendFeatures) -> float:
    """
    Score trend : -1.0 (bear) à +1.0 (bull)
    """
    w = INDICATOR_WEIGHTS["trend"]
    score = 0.0

    # EMA Cross 9/20
    score += t.ema_cross_9_20 * w["ema_cross"] * 0.6
    score += t.ema_cross_20_50 * w["ema_cross"] * 0.4

    # EMA Slope (normalisé -1 à +1)
    slope_norm = max(min(t.ema9_slope / 0.1, 1.0), -1.0)  # 0.1% = saturation
    score += slope_norm * w["ema_slope"]

    # VWAP
    score += t.price_vs_vwap * w["vwap"]

    return max(min(score, 1.0), -1.0)


def score_momentum(m: MomentumFeatures) -> float:
    """Score momentum : -1.0 à +1.0"""
    w = INDICATOR_WEIGHTS["momentum"]
    score = 0.0

    # RSI : centré sur 50
    rsi_score = (m.rsi - 50) / 50  # -1 à +1
    # Bonus si zones extrêmes
    if m.rsi < 30:
        rsi_score = (30 - m.rsi) / 30 * 1.2   # survendu → CALL fort
    elif m.rsi > 70:
        rsi_score = (m.rsi - 70) / 30 * -1.2  # suracheté → PUT fort
    score += max(min(rsi_score, 1.0), -1.0) * w["rsi"]

    # MACD
    macd_dir = 1 if m.macd_hist > 0 else -1
    macd_strength = min(abs(m.macd_hist) / (abs(m.macd) + 1e-10), 1.0)
    score += macd_dir * macd_strength * w["macd"]
    # Bonus cross
    score += m.macd_cross * 0.1

    # Stochastic RSI
    stoch_score = (m.stoch_k - 50) / 50
    score += stoch_score * w["stoch_rsi"] * 0.6
    score += m.stoch_zone * w["stoch_rsi"] * 0.4

    return max(min(score, 1.0), -1.0)


def score_volatility(v: VolatilityFeatures) -> Tuple[float, bool]:
    """
    Score volatilité : direction du rebond BB.
    Returns (score, block_signal)
    """
    block = v.is_high_vol
    if block:
        return 0.0, True

    w = INDICATOR_WEIGHTS["volatility"]
    score = 0.0

    # ATR : si faible ATR → signal plus fiable
    atr_factor = 1.0 if not v.is_high_vol else 0.5

    # Bollinger position : 0=bande basse, 1=bande haute
    bb_pos = v.bb_position
    if bb_pos < 0.15:
        bb_score = 1.0   # prix sur bande basse → rebond CALL
    elif bb_pos > 0.85:
        bb_score = -1.0  # prix sur bande haute → rebond PUT
    elif bb_pos < 0.35:
        bb_score = 0.4
    elif bb_pos > 0.65:
        bb_score = -0.4
    else:
        bb_score = 0.0   # zone neutre

    # Squeeze bonus (breakout imminent — directionnel uncertain)
    if v.is_squeeze:
        bb_score *= 0.3  # réduit l'impact

    score += bb_score * w["bollinger"] * atr_factor

    return max(min(score, 1.0), -1.0), False


def score_price_action(pa: PriceActionFeatures) -> float:
    """Score price action : -1.0 à +1.0"""
    w = INDICATOR_WEIGHTS["price_action"]
    score = 0.0

    # S/R levels : proximité
    # Si proche du support → CALL
    if pa.dist_to_support < pa.dist_to_resistance:
        sr_score = min(1.0, 0.5 / max(pa.dist_to_support, 0.01))
        score += sr_score * w["sr_levels"]
    else:
        sr_score = -min(1.0, 0.5 / max(pa.dist_to_resistance, 0.01))
        score += sr_score * w["sr_levels"]

    # Breakout
    breakout_score = pa.breakout_signal
    if pa.is_fakeout:
        breakout_score *= -0.5  # inverse si fakeout
    score += breakout_score * w["breakout"]

    # Wicks
    score += pa.wick_pressure * w["wicks"]

    return max(min(score, 1.0), -1.0)


def score_microstructure(m: MicrostructureFeatures) -> float:
    """Score microstructure : -1.0 à +1.0"""
    w = INDICATOR_WEIGHTS["microstructure"]
    score = 0.0

    # Speed (achat vs vente momentum)
    speed_norm = min(m.price_speed * 100, 1.0)  # normalise à 1%/s max
    speed_score = speed_norm * m.candle_direction
    score += speed_score * w["speed"]

    # Candle strength
    cs = m.candle_strength * m.candle_direction
    score += cs * w["candle_str"]

    # Volume pressure
    score += m.volume_pressure * w["vol_press"]

    # Consecutive candles bonus
    if m.consecutive_bulls >= 3:
        score += 0.15
    elif m.consecutive_bears >= 3:
        score -= 0.15

    return max(min(score, 1.0), -1.0)


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# ANALYSE PAR TIMEFRAME
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def analyze_timeframe(tf_label: str, candles: List[Candle]) -> Optional[TimeframeSignal]:
    """
    Analyse complète d'un timeframe donné.
    Extrait les features, calcule les scores par couche, fusionne.
    """
    if len(candles) < 25:
        logger.debug(f"TF {tf_label}: pas assez de bougies ({len(candles)})")
        return None

    # Extract features
    trend        = extract_trend(candles)
    momentum     = extract_momentum(candles)
    volatility   = extract_volatility(candles)
    price_action = extract_price_action(candles)
    micro        = extract_microstructure(candles)

    if not all([trend, momentum, volatility, price_action, micro]):
        return None

    # Scores par couche
    t_score = score_trend(trend)
    m_score = score_momentum(momentum)
    v_score, blocked = score_volatility(volatility)
    pa_score = score_price_action(price_action)
    ms_score = score_microstructure(micro)

    # Si haute volatilité → NO TRADE
    if blocked:
        return TimeframeSignal(
            timeframe=tf_label,
            direction="NEUTRAL",
            score=0.0,
            confidence=0.0,
            trend=trend, momentum=momentum, volatility=volatility,
            price_action=price_action, microstructure=micro,
            layer_scores={"blocked": 1.0},
        )

    # Fusion pondérée
    lw = LAYER_WEIGHTS
    total_score = (
        t_score  * lw["trend"]          +
        m_score  * lw["momentum"]       +
        v_score  * lw["volatility"]     +
        pa_score * lw["price_action"]   +
        ms_score * lw["microstructure"]
    )

    # Confiance : accord entre les couches
    scores = [t_score, m_score, v_score, pa_score, ms_score]
    pos    = sum(1 for s in scores if s > 0.1)
    neg    = sum(1 for s in scores if s < -0.1)
    agree  = max(pos, neg)
    confidence = (agree / 5) * abs(total_score)

    direction = "NEUTRAL"
    if total_score > 0.1:
        direction = "CALL"
    elif total_score < -0.1:
        direction = "PUT"

    return TimeframeSignal(
        timeframe=tf_label,
        direction=direction,
        score=round(total_score, 4),
        confidence=round(confidence, 4),
        trend=trend,
        momentum=momentum,
        volatility=volatility,
        price_action=price_action,
        microstructure=micro,
        layer_scores={
            "trend":          round(t_score, 3),
            "momentum":       round(m_score, 3),
            "volatility":     round(v_score, 3),
            "price_action":   round(pa_score, 3),
            "microstructure": round(ms_score, 3),
        },
    )


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# FUSION MULTI-TIMEFRAME
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def _contradiction_ratio(signals: List[TimeframeSignal]) -> float:
    """% de TF qui contredisent la direction majoritaire."""
    valid = [s for s in signals if s.direction != "NEUTRAL"]
    if not valid:
        return 1.0
    calls = sum(1 for s in valid if s.direction == "CALL")
    puts  = len(valid) - calls
    minority = min(calls, puts)
    return minority / len(valid)


def _build_reason(tf_sigs: List[TimeframeSignal], direction: str,
                  probability: float, blocked_reason: Optional[str]) -> str:
    """Construit une phrase d'explication humaine."""
    if blocked_reason:
        return blocked_reason

    if direction == "NO TRADE":
        return "Signaux multi-timeframe contradictoires ou confiance insuffisante"

    # Résume les TF alignés
    aligned = [s for s in tf_sigs if s.direction == direction]
    tf_list = ", ".join(s.timeframe for s in aligned[:3])
    prob_str = f"{probability:.0f}%"

    # Indicateur dominant
    if aligned:
        best = max(aligned, key=lambda s: abs(s.score))
        layers = best.layer_scores
        dominant = max(layers, key=lambda k: abs(layers[k]))
        dominant_map = {
            "trend": "tendance EMA",
            "momentum": "momentum RSI/MACD",
            "volatility": "position Bollinger",
            "price_action": "structure S/R",
            "microstructure": "pression de prix",
        }
        dominant_str = dominant_map.get(dominant, dominant)
        return (
            f"{direction} confirmé sur {tf_list} | "
            f"Signal dominant : {dominant_str} | "
            f"Probabilité : {prob_str}"
        )

    return f"{direction} | {prob_str}"


def fuse_signals(
    tf_signals: Dict[str, Optional[TimeframeSignal]],
    expiry: str,
    current_price: float,
    asset: str,
) -> SignalResponse:
    """
    Fusionne les signaux de tous les timeframes en une décision finale.
    Intègre la latence estimée dans le target_time.
    """
    cfg     = SIGNAL_CONFIG
    now_utc = datetime.now(timezone.utc)

    valid = {tf: s for tf, s in tf_signals.items() if s is not None}
    if not valid:
        return _no_trade(asset, expiry, current_price, now_utc, "Données insuffisantes")

    # Vérifie si un TF signale haute volatilité → blocage global
    blocked_tfs = [tf for tf, s in valid.items() if "blocked" in s.layer_scores]
    if len(blocked_tfs) >= 2:
        return _no_trade(asset, expiry, current_price, now_utc,
                         f"Volatilité excessive ({', '.join(blocked_tfs)})")

    # Filtre les NEUTRAL
    directional = [s for s in valid.values() if s.direction != "NEUTRAL"]
    if not directional:
        return _no_trade(asset, expiry, current_price, now_utc, "Absence de tendance claire")

    # Score global pondéré par TF weight
    total_weight = 0.0
    weighted_score = 0.0
    for tf_label, sig in valid.items():
        if sig.direction == "NEUTRAL":
            continue
        w = TIMEFRAMES[tf_label]["weight"]
        weighted_score += sig.score * w * sig.confidence
        total_weight   += w

    if total_weight == 0:
        return _no_trade(asset, expiry, current_price, now_utc, "Poids nuls")

    final_score = weighted_score / total_weight

    # Contradiction check
    all_sigs = list(valid.values())
    contra    = _contradiction_ratio(all_sigs)
    if contra > cfg["contradiction_limit"]:
        return _no_trade(
            asset, expiry, current_price, now_utc,
            f"Contradictions multi-TF ({contra:.0%} des TF contradictoires)"
        )

    # Direction
    if final_score > 0.08:
        direction = "CALL"
    elif final_score < -0.08:
        direction = "PUT"
    else:
        return _no_trade(asset, expiry, current_price, now_utc, "Score trop neutre")

    # Probabilité (conversion score → %)
    probability = min(50 + abs(final_score) * 50, 97.0)

    # Confiance globale
    avg_conf = sum(s.confidence for s in directional) / len(directional)

    if avg_conf < cfg["no_trade_threshold"]:
        return _no_trade(asset, expiry, current_price, now_utc,
                         f"Confiance globale insuffisante ({avg_conf:.0%})")

    if avg_conf >= cfg["min_confidence"] + 0.15:
        confidence_label = "HIGH"
    elif avg_conf >= cfg["min_confidence"]:
        confidence_label = "MEDIUM"
    else:
        confidence_label = "LOW"

    if avg_conf < cfg["min_confidence"]:
        return _no_trade(asset, expiry, current_price, now_utc,
                         f"Confiance trop faible ({avg_conf:.0%})")

    # TF breakdown
    tf_breakdown = {}
    for tf, sig in valid.items():
        if sig.direction == "NEUTRAL":
            tf_breakdown[tf] = "⚪ NEUTRE"
        elif sig.direction == direction:
            tf_breakdown[tf] = f"{'🔵' if direction == 'CALL' else '🔴'} {sig.direction} ({sig.score:+.2f})"
        else:
            tf_breakdown[tf] = f"⚠️ {sig.direction} ({sig.score:+.2f})"

    # Layer scores agrégés
    layer_agg: Dict[str, float] = {}
    for s in directional:
        for layer, sc in s.layer_scores.items():
            layer_agg[layer] = layer_agg.get(layer, 0) + sc
    for k in layer_agg:
        layer_agg[k] = round(layer_agg[k] / len(directional), 3)

    # Target time (expiry + latence)
    expiry_secs = EXPIRY_SECONDS.get(expiry, 60)
    target = now_utc + timedelta(seconds=expiry_secs + cfg["latency_seconds"])

    reason = _build_reason(directional, direction, probability, None)

    return SignalResponse(
        asset=asset,
        direction=direction,
        probability=round(probability, 1),
        confidence=confidence_label,
        expiry=expiry,
        target_time=target.strftime("%H:%M:%S UTC"),
        reason=reason,
        current_price=round(current_price, 6),
        tf_breakdown=tf_breakdown,
        layer_scores=layer_agg,
        generated_at=now_utc.strftime("%H:%M:%S UTC"),
        signal_age_ok=True,
    )


def _no_trade(asset: str, expiry: str, price: float,
              now: datetime, reason: str) -> SignalResponse:
    expiry_secs = EXPIRY_SECONDS.get(expiry, 60)
    target = now + timedelta(seconds=expiry_secs + SIGNAL_CONFIG["latency_seconds"])
    return SignalResponse(
        asset=asset,
        direction="NO TRADE",
        probability=50.0,
        confidence="INSUFFICIENT",
        expiry=expiry,
        target_time=target.strftime("%H:%M:%S UTC"),
        reason=reason,
        current_price=round(price, 6),
        tf_breakdown={},
        layer_scores={},
        generated_at=now.strftime("%H:%M:%S UTC"),
        signal_age_ok=True,
    )


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# SIGNAL ENGINE — orchestrateur
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

class SignalEngine:
    """
    Orchestre l'analyse multi-TF et produit le signal final.
    Utilise un cache TTL pour éviter les recalculs trop fréquents.
    """

    def __init__(self, market_data):
        self.market_data = market_data
        self._cache: Dict[str, Tuple[SignalResponse, float]] = {}
        self._ttl = SIGNAL_CONFIG["cache_ttl_seconds"]

    async def analyze(self, asset: str, expiry: str = "1m") -> SignalResponse:
        """
        Analyse complète d'un actif.
        Utilise le cache si le signal est récent.
        """
        cache_key = f"{asset}:{expiry}"
        cached = self._cache.get(cache_key)
        if cached and (time.time() - cached[1]) < self._ttl:
            sig = cached[0]
            age = time.time() - cached[1]
            sig.signal_age_ok = age < SIGNAL_CONFIG["max_signal_age"]
            return sig

        price = self.market_data.get_price(asset) or 0.0

        if not self.market_data.is_ready(asset):
            return _no_trade(asset, expiry, price,
                             datetime.now(timezone.utc), "Chargement des données...")

        # Analyse chaque TF en parallèle
        tf_results: Dict[str, Optional[TimeframeSignal]] = {}

        async def _analyze_tf(tf_label: str):
            candles = self.market_data.get_candles(asset, tf_label)
            if len(candles) < 20:
                tf_results[tf_label] = None
                return
            loop = asyncio.get_event_loop()
            # CPU-bound → run in executor pour ne pas bloquer la boucle
            result = await loop.run_in_executor(
                None, analyze_timeframe, tf_label, candles
            )
            tf_results[tf_label] = result

        await asyncio.gather(*[_analyze_tf(tf) for tf in TIMEFRAMES])

        signal = fuse_signals(tf_results, expiry, price, asset)
        self._cache[cache_key] = (signal, time.time())

        logger.info(
            f"[{asset}] {signal.direction} | {signal.probability:.1f}% | "
            f"{signal.confidence} | exp:{expiry}"
        )
        return signal

    async def analyze_all(self, expiry: str = "1m") -> Dict[str, SignalResponse]:
        """Analyse tous les actifs en parallèle."""
        from config import ASSET_SYMBOLS
        results = await asyncio.gather(
            *[self.analyze(s, expiry) for s in ASSET_SYMBOLS],
            return_exceptions=True,
        )
        out = {}
        for sym, res in zip(ASSET_SYMBOLS, results):
            if isinstance(res, Exception):
                logger.error(f"analyze_all {sym}: {res}")
            else:
                out[sym] = res
        return out
