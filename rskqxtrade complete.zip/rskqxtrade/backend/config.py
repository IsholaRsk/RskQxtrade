"""
RSKQxTrade — Configuration centrale
Toutes les constantes, clés API, paramètres système
"""
import os
from dataclasses import dataclass, field
from typing import List

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# CLÉS API (priorité variables d'environnement)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

TWELVEDATA_API_KEY  = os.environ.get("TWELVEDATA_API_KEY",  "c3c307ede4dd401b84a4493efd4f9f04")
TELEGRAM_BOT_TOKEN  = os.environ.get("TELEGRAM_BOT_TOKEN",  "8788118641:AAHt37OfJqVvHiB3f_BTZiLc59L9tiztJXk")
TELEGRAM_BOT_ID     = os.environ.get("TELEGRAM_BOT_ID",     "7645848739")
SUPABASE_URL        = os.environ.get("SUPABASE_URL",         "")
SUPABASE_KEY        = os.environ.get("SUPABASE_KEY",         "")

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# ACTIFS
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

ASSETS = {
    "EUR/USD": {
        "symbol":     "EUR/USD",
        "type":       "forex",
        "td_symbol":  "EUR/USD",
        "precision":  5,
        "pip":        0.00001,
        "category":   "major",
    },
    "BTC/USD": {
        "symbol":     "BTC/USD",
        "type":       "crypto",
        "td_symbol":  "BTC/USD",
        "precision":  2,
        "pip":        1.0,
        "category":   "crypto",
    },
    "GBP/USD": {
        "symbol":     "GBP/USD",
        "type":       "forex",
        "td_symbol":  "GBP/USD",
        "precision":  5,
        "pip":        0.00001,
        "category":   "major",
    },
    "XAU/USD": {
        "symbol":     "XAU/USD",
        "type":       "commodity",
        "td_symbol":  "XAU/USD",
        "precision":  3,
        "pip":        0.01,
        "category":   "commodity",
    },
    "USD/JPY": {
        "symbol":     "USD/JPY",
        "type":       "forex",
        "td_symbol":  "USD/JPY",
        "precision":  3,
        "pip":        0.001,
        "category":   "major",
    },
}

ASSET_SYMBOLS = list(ASSETS.keys())

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# TIMEFRAMES
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

TIMEFRAMES = {
    "5s":  {"seconds": 5,    "td_interval": "1min",  "bars_needed": 120, "weight": 0.10},
    "15s": {"seconds": 15,   "td_interval": "1min",  "bars_needed": 100, "weight": 0.12},
    "30s": {"seconds": 30,   "td_interval": "1min",  "bars_needed": 100, "weight": 0.15},
    "1m":  {"seconds": 60,   "td_interval": "1min",  "bars_needed": 100, "weight": 0.22},
    "2m":  {"seconds": 120,  "td_interval": "2min",  "bars_needed": 80,  "weight": 0.20},
    "5m":  {"seconds": 300,  "td_interval": "5min",  "bars_needed": 60,  "weight": 0.21},
}

# Expirations disponibles dans l'app
EXPIRATIONS = ["1m", "2m", "3m", "5m", "10m", "15m"]

EXPIRY_SECONDS = {
    "1m": 60, "2m": 120, "3m": 180,
    "5m": 300, "10m": 600, "15m": 900,
}

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# PARAMÈTRES SIGNAL ENGINE
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

SIGNAL_CONFIG = {
    "min_confidence":        0.62,   # Seuil minimal pour émettre un signal
    "no_trade_threshold":    0.55,   # En dessous → NO TRADE
    "contradiction_limit":   0.35,   # Si trop de TF contradictoires → NO TRADE
    "volatility_block_atr":  2.5,    # Multiplicateur ATR pour blocage haute volatilité
    "latency_seconds":       3,      # Latence estimée réseau + traitement
    "cache_ttl_seconds":     8,      # TTL du cache signal
    "max_signal_age":        30,     # Âge max d'un signal valide (secondes)
}

# Poids des couches d'analyse
LAYER_WEIGHTS = {
    "trend":          0.30,
    "momentum":       0.28,
    "volatility":     0.18,
    "price_action":   0.14,
    "microstructure": 0.10,
}

# Poids indicateurs par couche
INDICATOR_WEIGHTS = {
    "trend": {
        "ema_cross":  0.40,
        "ema_slope":  0.30,
        "vwap":       0.30,
    },
    "momentum": {
        "rsi":        0.35,
        "macd":       0.35,
        "stoch_rsi":  0.30,
    },
    "volatility": {
        "atr":        0.40,
        "bollinger":  0.60,
    },
    "price_action": {
        "sr_levels":  0.35,
        "breakout":   0.35,
        "wicks":      0.30,
    },
    "microstructure": {
        "speed":      0.35,
        "candle_str": 0.35,
        "vol_press":  0.30,
    },
}

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# TWELVEDATA URLs
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

TD_REST_BASE = "https://api.twelvedata.com"
TD_WS_URL    = "wss://ws.twelvedata.com/v1/quotes/price"

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# APP
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

APP_HOST    = "0.0.0.0"
APP_PORT    = int(os.environ.get("PORT", 8000))
DEBUG       = os.environ.get("DEBUG", "false").lower() == "true"
APP_URL     = os.environ.get("APP_URL", "https://rskqxtradebot.vercel.app")
WEBAPP_URL  = f"{APP_URL}/app"
