"""
RSKQxTrade — Point d'entrée principal
Lance FastAPI (API + WebSocket) + Bot Telegram en parallèle
"""
import asyncio
import logging
import os
import sys

import uvicorn
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

# Ajoute le backend au path
sys.path.insert(0, os.path.dirname(__file__))

from config import APP_HOST, APP_PORT, TELEGRAM_BOT_TOKEN, APP_URL, DEBUG
from api.routes import app as fastapi_app
from telegram_bot import build_bot, setup_webhook

logging.basicConfig(
    level=logging.DEBUG if DEBUG else logging.INFO,
    format="%(asctime)s | %(name)s | %(levelname)s | %(message)s",
)
logger = logging.getLogger("main")

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# WEBHOOK TELEGRAM (monté sur FastAPI pour Vercel)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

_tg_app = None

@fastapi_app.on_event("startup")
async def startup_telegram():
    global _tg_app
    webhook_url = f"{APP_URL}/webhook/telegram"
    try:
        _tg_app = await setup_webhook(webhook_url)
        logger.info(f"✅ Telegram webhook: {webhook_url}")
    except Exception as e:
        logger.warning(f"Webhook setup failed ({e}) — polling mode")
        # Fallback: lance le polling en tâche de fond
        asyncio.create_task(_run_polling())


async def _run_polling():
    """Fallback polling (local / Replit)."""
    global _tg_app
    try:
        bot = build_bot()
        await bot.initialize()
        await bot.start()
        await bot.updater.start_polling(drop_pending_updates=True)
        _tg_app = bot
        logger.info("✅ Bot Telegram démarré (polling)")
    except Exception as e:
        logger.error(f"Polling failed: {e}")


@fastapi_app.post("/webhook/telegram")
async def telegram_webhook(request: Request):
    """Endpoint webhook Telegram."""
    global _tg_app
    if not _tg_app:
        return JSONResponse({"ok": False, "error": "Bot not initialized"}, status_code=503)
    try:
        import json
        from telegram import Update
        data = await request.json()
        update = Update.de_json(data, _tg_app.bot)
        await _tg_app.process_update(update)
        return JSONResponse({"ok": True})
    except Exception as e:
        logger.error(f"Webhook error: {e}")
        return JSONResponse({"ok": False, "error": str(e)}, status_code=500)


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# LANCEMENT
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

if __name__ == "__main__":
    logger.info(f"🚀 Démarrage RSKQxTrade sur {APP_HOST}:{APP_PORT}")
    uvicorn.run(
        "main:fastapi_app",
        host=APP_HOST,
        port=APP_PORT,
        reload=DEBUG,
        log_level="debug" if DEBUG else "info",
        ws_ping_interval=20,
        ws_ping_timeout=10,
    )
